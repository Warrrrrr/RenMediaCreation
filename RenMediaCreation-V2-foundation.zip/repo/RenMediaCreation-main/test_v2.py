from strategy_engine import select_strategies
from validator import validate_script


def test_strategy_budget():
    result = select_strategies("why women lose interest fast", "adult men", "understand relationship patterns", 10)
    assert len(result["selected"]) <= result["budget"]
    assert "point_development" in [x["key"] for x in result["selected"]]


def test_validator_catches_personal_experience():
    result = validate_script("I remember sitting in my living room years ago.", 10)
    assert any("first-person" in x.lower() for x in result["critical"])


def test_validator_flags_percentage():
    result = validate_script("Researchers found that 93% of people do this.", 10)
    assert any("percentage" in x.lower() for x in result["warnings"])


def test_validator_catches_technique_jargon():
    result = validate_script("This activates the Zeigarnik Effect and creates an open loop.", 12)
    assert any("technique terminology" in x.lower() for x in result["critical"])


if __name__ == "__main__":
    test_strategy_budget()
    test_validator_catches_personal_experience()
    test_validator_flags_percentage()
    test_validator_catches_technique_jargon()
    print("Ren Media V2 foundation tests: PASS")
