"""Deterministic strategy selection for Ren Media V2.

This module does not call an LLM. It ranks the existing strategy library based
on topic signals and enforces a small strategy budget. Gemini may propose or
refine the content analysis, but Python owns the selection constraints.
"""

from strategies import STRATEGIES

BASE_PRIORITY = [
    "self_verification_theory",
    "curiosity_gaps",
    "point_development",
    "point_ordering",
    "pattern_interrupts",
]

CATEGORY_LIMITS = {
    "attention": 2,
    "curiosity": 1,
    "emotion": 1,
    "persuasion": 2,
    "trust": 1,
    "structure": 2,
    "storytelling": 1,
    "cta": 1,
}

CONFLICTS = {
    frozenset(("scarcity", "choice_architecture")): "Do not manufacture urgency while presenting the choice as neutral.",
    frozenset(("emotional_triggers", "authority")): "High emotional intensity can distort perceived certainty; keep authority claims evidence-calibrated.",
    frozenset(("foot_in_the_door_content", "choice_architecture")): "Progressive agreement must not conceal meaningful alternatives.",
}


def _signals(topic, audience="", objective=""):
    text = f"{topic} {audience} {objective}".lower()
    return set(w.strip(".,!?()[]{}\"'") for w in text.split() if len(w) > 2)


def _score(key, topic, audience, objective):
    s = STRATEGIES[key]
    tokens = _signals(topic, audience, objective)
    score = 0
    for kw in s.get("keywords", []):
        if kw.lower() in tokens or kw.lower() in f"{topic} {audience} {objective}".lower():
            score += 2
    if key in BASE_PRIORITY:
        score += 1
    if key in {"authority", "social_proof", "scarcity", "foot_in_the_door_audience"}:
        # These require stronger topical justification and should not become defaults.
        score -= 1
    return score


def select_strategies(topic, audience="", objective="", length_minutes=10, requested=None):
    try:
        minutes = max(1.0, float(length_minutes))
    except (TypeError, ValueError):
        minutes = 10.0

    # Deliberately conservative: the script should have a few dominant strategies,
    # not a checklist of every psychological device.
    budget = 3 if minutes <= 6 else 4 if minutes <= 10 else 5 if minutes <= 20 else 6

    candidates = []
    for key in STRATEGIES:
        score = _score(key, topic, audience, objective)
        if requested and key in requested:
            score += 5
        candidates.append((score, key))
    candidates.sort(key=lambda x: (-x[0], x[1]))

    selected = []
    category_counts = {}
    for score, key in candidates:
        if score <= 0 and len(selected) >= 3:
            continue
        category = STRATEGIES[key]["category"]
        if category_counts.get(category, 0) >= CATEGORY_LIMITS.get(category, 2):
            continue
        selected.append(key)
        category_counts[category] = category_counts.get(category, 0) + 1
        if len(selected) >= budget:
            break

    # Always keep structural development in the plan, even when topic signals are weak.
    for required in ("point_development", "point_ordering"):
        if required not in selected and len(selected) < budget:
            selected.append(required)

    intensity = {}
    for key in selected:
        base = STRATEGIES[key]["intensity"]
        if key in {"emotional_triggers", "scarcity"}:
            intensity[key] = "low" if base != "high" else "medium"
        else:
            intensity[key] = base

    conflicts = []
    for i, a in enumerate(selected):
        for b in selected[i + 1:]:
            message = CONFLICTS.get(frozenset((a, b)))
            if message:
                conflicts.append({"strategies": [a, b], "message": message})

    return {
        "budget": budget,
        "selected": [
            {
                "key": key,
                "name": STRATEGIES[key]["name"],
                "role": STRATEGIES[key]["primary_purpose"],
                "locations": STRATEGIES[key]["locations"],
                "intensity": intensity[key],
                "why_selected": "Topic relevance and strategy-budget rules.",
            }
            for key in selected
        ],
        "excluded": [
            {"key": key, "name": STRATEGIES[key]["name"]}
            for key in STRATEGIES if key not in selected
        ],
        "conflicts": conflicts,
    }
