"""Lightweight deterministic validator for Ren Media V2.

It deliberately catches observable failure patterns without pretending that
regex can prove factual truth. Qualitative factual verification remains a
separate concern and is surfaced as a review warning.
"""

import re
from governance import PERSONAL_EXPERIENCE_FIREWALL, PSYCHOLOGY_FIREWALL


def _word_count(text):
    return len(re.findall(r"\b[\w'’-]+\b", text))


def _find(pattern, text, flags=re.I):
    return list(re.finditer(pattern, text, flags))


def validate_script(script, target_words=None, selected_strategy_keys=None):
    critical = []
    warnings = []
    passed = []

    words = _word_count(script)
    if target_words:
        ratio = words / max(1, target_words)
        if ratio < 0.90 or ratio > 1.10:
            critical.append(f"Length is {words} words versus a target of {target_words} (outside ±10%).")
        else:
            passed.append("Length is within ±10% of target.")

    # Personal experience firewall: first-person experiential constructions are
    # review flags because the generator has no independent biography source.
    personal = _find(r"\b(I|I've|I’d|I used to|I remember|in my life|my relationship|my clients?)\b", script)
    if personal:
        critical.append("Possible fabricated first-person experience or biography. Every first-person lived claim must come from supplied source material.")
    else:
        passed.append("No obvious first-person lived-experience claim detected.")

    # Unsupported precision: this is a signal, not a factuality proof.
    numeric = _find(r"\b\d+(?:\.\d+)?%|\b(?:ninety|eighty|seventy|sixty|fifty|forty|thirty|twenty) percent\b", script)
    if numeric:
        warnings.append("Specific percentage/statistical claims require source verification.")
    else:
        passed.append("No specific percentage claims detected.")

    causal = _find(r"\b(?:causes?|caused|guarantees?|proves?|will make you|makes you)\b", script)
    if causal:
        warnings.append("Strong causal/guarantee language detected; verify that the evidence supports the strength of each claim.")

    physiology = _find(r"\b(?:heart rate|nervous system|cortisol|dopamine|brain|immune system|physiological|chemical)\b", script)
    if physiology:
        warnings.append("Physiological language detected; verify scientific support and avoid presenting mechanism as certainty.")

    it_is_not = _find(r"\b(?:it isn't|it is not)\b[^.!?]{0,80}\b(?:it's|it is)\b", script)
    if len(it_is_not) > 3:
        warnings.append("Repeated 'It isn't X, it's Y' rhetorical pattern detected.")

    truth_is = _find(r"\bthe truth is\b", script)
    if len(truth_is) > 2:
        warnings.append("Repeated 'The truth is' construction detected.")

    cta = _find(r"\b(?:subscribe|hit the subscribe button|like and subscribe|comment below|type ['\"]?(?:yes|no))\b", script)
    if cta:
        # CTA inside the first 70% is not automatically wrong; it is a review flag.
        first_cta = cta[0].start() / max(1, len(script))
        if first_cta < 0.70:
            warnings.append("CTA appears before the final third; check that it does not interrupt unresolved narrative tension.")
        else:
            passed.append("Main CTA appears late in the script.")

    jargon = _find(r"\b(?:open loop|macro loop|rehook|pattern interrupt|foot-in-the-door|Zeigarnik|Cialdini|nudge|choice architecture)\b", script)
    if jargon:
        critical.append("Technique terminology appears in narration. Execute the technique; do not name the technique to the viewer.")
    else:
        passed.append("No obvious scripting-technique jargon detected in narration.")

    emotional = _find(r"\b(?:terrifying|destroy|dead|poison|guaranteed|doomed|catastrophic|life[- ]?changing|you won't stand a chance)\b", script)
    if len(emotional) >= 5:
        warnings.append("High-intensity language appears frequently; check for emotional escalation without explanatory relief.")

    if not critical:
        passed.append("No deterministic critical failure detected.")

    return {
        "status": "CRITICAL" if critical else ("WARNING" if warnings else "PASS"),
        "critical": critical,
        "warnings": warnings,
        "passed": passed,
        "word_count": words,
    }
