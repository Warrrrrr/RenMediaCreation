"""Ren Media V2 governance rules shared by generation and validation."""

PERSONAL_EXPERIENCE_FIREWALL = [
    "Never invent first-person memories, relationships, jobs, credentials, clients, years of experience, or lived events.",
    "A first-person claim is allowed only when explicitly supplied by the user/source material.",
    "Hypothetical scenes must be framed as hypothetical (for example, 'imagine' or 'suppose').",
]

CLAIM_TYPES = {
    "fact": "A claim presented as externally verifiable reality; requires appropriate evidence when consequential.",
    "inference": "A conclusion drawn from stated evidence; must not be stronger than the evidence.",
    "interpretation": "An explanatory reading or framing; should be signposted when uncertainty matters.",
    "example": "A hypothetical or illustrative scenario; must not masquerade as a real event.",
    "hypothesis": "A possible explanation; use calibrated language such as may, could, or one possibility.",
    "personal_experience": "A first-person event; allowed only from supplied source material.",
}

PSYCHOLOGY_FIREWALL = [
    "Do not use a named psychological effect merely to make ordinary advice sound scientific.",
    "Do not convert an association into a causal claim.",
    "Do not claim a psychological mechanism is universal unless the evidence supports that scope.",
    "Do not attach precise percentages, physiological effects, or guaranteed outcomes without source support.",
]

EMOTIONAL_RULES = [
    "Do not escalate every section; alternate emotional intensity with explanation, specificity, or calm reflection.",
    "Fear, shame, outrage, and urgency must correspond to a real consequence in the topic.",
    "Avoid absolute language when the underlying claim is uncertain.",
]

RHETORICAL_RULES = [
    "Avoid repeated 'It isn't X, it's Y' constructions.",
    "Avoid repeated 'The truth is...' openings.",
    "Avoid repeated 'But here's the...' transitions.",
    "Avoid consecutive paragraphs built from the same rhetorical template.",
    "Do not announce technique names to the viewer.",
]

CTA_RULES = [
    "The main CTA belongs after the substantive payoff.",
    "A mid-video audience ask must occur at a natural pause, not inside unresolved narrative tension.",
    "Do not use artificial urgency to force engagement.",
]

ETHICAL_RULES = [
    "Persuasion techniques must improve clarity or voluntary action, not conceal material information or coerce the viewer.",
    "Do not manufacture fear, scarcity, authority, social proof, or personal credibility.",
    "Do not exploit sensitive personal vulnerabilities merely to increase retention.",
]


def governance_prompt():
    return "\n".join([
        "PERSONAL EXPERIENCE FIREWALL:", *[f"- {x}" for x in PERSONAL_EXPERIENCE_FIREWALL],
        "CLAIM TYPES:", *[f"- {k}: {v}" for k, v in CLAIM_TYPES.items()],
        "PSYCHOLOGY FIREWALL:", *[f"- {x}" for x in PSYCHOLOGY_FIREWALL],
        "EMOTIONAL RULES:", *[f"- {x}" for x in EMOTIONAL_RULES],
        "RHETORICAL RULES:", *[f"- {x}" for x in RHETORICAL_RULES],
        "CTA RULES:", *[f"- {x}" for x in CTA_RULES],
        "ETHICAL RULES:", *[f"- {x}" for x in ETHICAL_RULES],
    ])
